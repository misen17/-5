# Internal QA tool: no shrinking rules required.
