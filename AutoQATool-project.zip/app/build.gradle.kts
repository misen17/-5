plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.autoqatool"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.autoqatool"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "2.0.0-zero-code"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
