package com.example.autoqatool;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText loops;
    private CheckBox screenshots;
    private CheckBox autoStart;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        loadPrefs();
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        int p = dp(18);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("Auto QA Tool 零代码版");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        body.addView(title);

        TextView scope = new TextView(this);
        scope.setText("零代码内置测试版\n自动化范围永久锁定在本 APK 自己的测试页面，不会操作其他 App。\n安装后只需开悬浮窗和无障碍权限即可运行。");
        scope.setTextSize(15);
        scope.setPadding(0, dp(12), 0, dp(16));
        body.addView(scope);

        TextView l1 = new TextView(this);
        l1.setText("循环次数");
        body.addView(l1);

        loops = new EditText(this);
        loops.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        loops.setSingleLine(true);
        body.addView(loops);

        screenshots = new CheckBox(this);
        screenshots.setText("每完成一轮自动截图（异常始终截图）");
        body.addView(screenshots);

        autoStart = new CheckBox(this);
        autoStart.setText("开机/服务重连后自动继续测试");
        body.addView(autoStart);

        Button save = button("保存配置", v -> savePrefs());
        body.addView(save);

        Button overlay = button("1. 授予悬浮窗权限", v -> openOverlayPermission());
        body.addView(overlay);

        Button accessibility = button("2. 开启无障碍测试服务", v -> {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(i);
        });
        body.addView(accessibility);

        Button launch = button("3. 打开内置测试页面", v -> launchTarget());
        body.addView(launch);

        Button start = button("开始 / 继续", v -> {
            savePrefs();
            AutomationAccessibilityService s = AutomationAccessibilityService.getInstance();
            if (s == null) {
                toast("请先在系统设置中开启 Auto QA Test Service");
            } else {
                s.startAutomationFromUi();
                refreshStatus();
            }
        });
        body.addView(start);

        Button pause = button("暂停", v -> {
            AutomationAccessibilityService s = AutomationAccessibilityService.getInstance();
            if (s != null) s.pauseAutomation("main-ui");
            refreshStatus();
        });
        body.addView(pause);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, dp(14), 0, 0);
        body.addView(status);

        TextView note = new TextView(this);
        note.setText("不需要填写包名，不需要修改代码，不需要配置 resource-id。\n\n" +
                "运行路线：短视频结束 → 直播/广告商品 → 加入测试购物车 → 返回 → 倒计时结束 → 上划 → 下一轮。\n\n" +
                "日志与截图目录：\n" + FileLogger.basePath(this));
        note.setTextSize(13);
        note.setPadding(0, dp(12), 0, dp(40));
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        return scroll;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void loadPrefs() {
        loops.setText(String.valueOf(AutomationConfig.loopTarget(this)));
        screenshots.setChecked(AutomationConfig.screenshotEachLoop(this));
        autoStart.setChecked(AutomationConfig.autoStart(this));
    }

    private void savePrefs() {
        int count = 20;
        try { count = Integer.parseInt(loops.getText().toString().trim()); } catch (Exception ignored) {}
        count = Math.max(1, Math.min(count, 100000));
        AutomationConfig.prefs(this).edit()
                .putInt("loop_target", count)
                .putBoolean("screenshot_each_loop", screenshots.isChecked())
                .putBoolean("auto_start", autoStart.isChecked())
                .apply();
        toast("配置已保存");
        refreshStatus();
    }

    private void openOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("悬浮窗权限已开启");
            return;
        }
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void launchTarget() {
        Intent i = new Intent(this, DemoVideoActivity.class);
        startActivity(i);
    }

    private void refreshStatus() {
        if (status == null) return;
        AutomationAccessibilityService s = AutomationAccessibilityService.getInstance();
        String service = s == null ? "未连接" : "已连接";
        String engine = s == null ? "-" : s.getPublicStatus();
        status.setText("无障碍服务：" + service + "\n引擎：" + engine + "\n悬浮窗：" +
                (Settings.canDrawOverlays(this) ? "已授权" : "未授权"));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
