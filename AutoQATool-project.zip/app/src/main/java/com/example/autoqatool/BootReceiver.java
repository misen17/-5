package com.example.autoqatool;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
                Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(intent.getAction())) {
            FileLogger.log(context, "BOOT received; autoStart=" + AutomationConfig.autoStart(context));
            // Do not try to auto-grant Accessibility or overlay permissions.
            // When Accessibility is enabled, Android reconnects the service and
            // AutomationAccessibilityService.onServiceConnected() reads autoStart.
        }
    }
}
