package com.example.autoqatool;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DemoLiveActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = DemoUi.page(this,
                "测试直播间",
                "模拟主播讲解商品。自动化服务会找到商品入口并进入商品页。");

        TextView speaker = DemoUi.text(this, "主播测试话术：这是内部 QA 商品，不会产生真实订单。\n当前只验证页面跳转与状态机。 ");
        root.addView(speaker, DemoUi.full());

        Button product = DemoUi.button(this, "查看主播讲解商品");
        product.setId(R.id.product_entry);
        product.setOnClickListener(v -> {
            Intent i = new Intent(this, DemoProductActivity.class);
            i.putExtra("source", "live");
            startActivity(i);
        });
        root.addView(product);

        setContentView(root);
    }
}
