package com.example.autoqatool;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DemoVideoActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private TextView videoFinished;
    private TextView adDone;
    private Button entry;
    private boolean journeyStarted = false;
    private int cycleIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cycleIndex = AutomationConfig.demoCycle(this);
        buildPage();
        startVideoFixture();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        cycleIndex = AutomationConfig.demoCycle(this);
        journeyStarted = false;
        startVideoFixture();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (journeyStarted) {
            handler.removeCallbacksAndMessages(null);
            adDone.setVisibility(View.GONE);
            handler.postDelayed(() -> adDone.setVisibility(View.VISIBLE), 1200L);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void buildPage() {
        root = DemoUi.page(this,
                "内置短视频 / 广告测试页",
                "这是 APK 自己的测试环境，不会操作抖音、快手、视频号或其他第三方 App。\n每一轮自动在“直播商品”和“普通广告商品”两条路线之间切换。");

        videoFinished = DemoUi.text(this, "✓ 短视频播放结束");
        videoFinished.setId(R.id.video_finished);
        root.addView(videoFinished, DemoUi.full());

        entry = DemoUi.button(this, "");
        root.addView(entry);

        adDone = DemoUi.text(this, "✓ 广告倒计时结束，可以上划下一条");
        adDone.setId(R.id.ad_countdown_finished);
        root.addView(adDone, DemoUi.full());

        TextView tip = DemoUi.text(this, "页面会自动出现测试状态。开启无障碍服务后，不需要手动点击这些按钮。");
        root.addView(tip, DemoUi.full());

        setContentView(root);
    }

    private void startVideoFixture() {
        handler.removeCallbacksAndMessages(null);
        videoFinished.setVisibility(View.GONE);
        entry.setVisibility(View.GONE);
        adDone.setVisibility(View.GONE);

        boolean liveBranch = cycleIndex % 2 == 0;
        if (liveBranch) {
            entry.setId(R.id.enter_live_room);
            entry.setText("进入测试直播间");
            entry.setOnClickListener(v -> {
                journeyStarted = true;
                startActivity(new Intent(this, DemoLiveActivity.class));
            });
        } else {
            entry.setId(R.id.ad_product_link);
            entry.setText("打开广告商品");
            entry.setOnClickListener(v -> {
                journeyStarted = true;
                Intent i = new Intent(this, DemoProductActivity.class);
                i.putExtra("source", "ad");
                startActivity(i);
            });
        }

        handler.postDelayed(() -> {
            videoFinished.setVisibility(View.VISIBLE);
            entry.setVisibility(View.VISIBLE);
        }, 1200L);
    }
}
