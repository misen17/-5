package com.example.autoqatool;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DemoProductActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String source = getIntent().getStringExtra("source");
        if (source == null) source = "test";

        LinearLayout root = DemoUi.page(this,
                "测试商品页",
                "来源：" + source + "\n这里只模拟“加入购物车”按钮，不连接真实商城，也不会下单或付款。");

        TextView info = DemoUi.text(this, "测试商品：QA 演示商品 A\n价格：¥0（模拟）\n库存：测试数据");
        root.addView(info, DemoUi.full());

        Button add = DemoUi.button(this, "加入测试购物车");
        add.setId(R.id.add_to_cart);
        add.setOnClickListener(v -> {
            add.setText("✓ 已加入测试购物车");
            add.setEnabled(false);
        });
        root.addView(add);

        setContentView(root);
    }
}
