package com.example.autoqatool;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile AutomationAccessibilityService instance;

    private enum State {
        PAUSED,
        WAIT_VIDEO_END,
        FIND_ENTRY,
        WAIT_PRODUCT_ENTRY,
        WAIT_ADD_TO_CART,
        BACK_TO_AD,
        WAIT_AD_DONE,
        SWIPE_NEXT,
        RECOVERING
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat fileTs = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US);
    private final Runnable tickRunnable = this::tick;

    private State state = State.PAUSED;
    private boolean running = false;
    private int completedLoops = 0;
    private int backStepsRemaining = 0;
    private int recoveryStep = 0;
    private int consecutiveErrors = 0;
    private long stateEnteredAt = 0L;
    private long nextAllowedAt = 0L;

    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private Button overlayToggle;

    public static AutomationAccessibilityService getInstance() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        FileLogger.log(this, "Accessibility service connected; target=" + AutomationConfig.TARGET_PACKAGE);
        showOverlayIfAllowed();
        if (AutomationConfig.autoStart(this)) {
            handler.postDelayed(() -> startAutomation("auto-start"), 1800L);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // The engine uses a timed state machine. Events simply wake it quickly.
        if (running) scheduleTick(80L);
    }

    @Override
    public void onInterrupt() {
        FileLogger.log(this, "Accessibility service interrupted");
        pauseAutomation("interrupt");
    }

    @Override
    public void onDestroy() {
        removeOverlay();
        handler.removeCallbacksAndMessages(null);
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public void startAutomationFromUi() {
        startAutomation("main-ui");
    }

    public void pauseAutomation(String reason) {
        running = false;
        state = State.PAUSED;
        handler.removeCallbacks(tickRunnable);
        FileLogger.log(this, "PAUSE reason=" + reason + " loops=" + completedLoops);
        updateOverlay();
    }

    public String getPublicStatus() {
        return (running ? "运行中" : "暂停") + " / " + state + " / " + completedLoops + "/" + AutomationConfig.loopTarget(this);
    }

    private void startAutomation(String reason) {
        if (!isTargetInstalled()) {
            FileLogger.log(this, "START blocked: target app not installed");
            updateOverlay();
            return;
        }
        completedLoops = 0;
        consecutiveErrors = 0;
        AutomationConfig.setDemoCycle(this, 0);
        running = true;
        transition(State.WAIT_VIDEO_END, "start:" + reason);
        launchTargetApp();
        showOverlayIfAllowed();
        scheduleTick(1200L);
    }

    private void tick() {
        if (!running) return;
        long now = System.currentTimeMillis();
        if (now < nextAllowedAt) {
            scheduleTick(Math.min(400L, nextAllowedAt - now));
            return;
        }

        try {
            // Scope guard: never interact with any package except the owned test package.
            AccessibilityNodeInfo root = getRootInActiveWindow();
            CharSequence currentPkg = root == null ? null : root.getPackageName();
            if (currentPkg != null && !AutomationConfig.TARGET_PACKAGE.contentEquals(currentPkg)) {
                FileLogger.log(this, "Scope guard: active package=" + currentPkg + "; no interaction performed");
                if (state != State.RECOVERING) {
                    launchTargetApp();
                    nextAllowedAt = now + 1200L;
                }
                scheduleTick(500L);
                return;
            }

            switch (state) {
                case WAIT_VIDEO_END:
                    if (findById(AutomationConfig.ID_VIDEO_FINISHED) != null) {
                        transition(State.FIND_ENTRY, "video_finished");
                    } else if (stateTimedOut(120_000L)) {
                        beginRecovery("video end timeout", null);
                    }
                    break;

                case FIND_ENTRY:
                    AccessibilityNodeInfo live = findById(AutomationConfig.ID_ENTER_LIVE);
                    if (live != null) {
                        if (clickNode(live)) {
                            backStepsRemaining = 2;
                            transition(State.WAIT_PRODUCT_ENTRY, "entered live test page");
                            nextAllowedAt = now + 900L;
                        }
                    } else {
                        AccessibilityNodeInfo adProduct = findById(AutomationConfig.ID_AD_PRODUCT_LINK);
                        if (adProduct != null && clickNode(adProduct)) {
                            backStepsRemaining = 1;
                            transition(State.WAIT_ADD_TO_CART, "opened ad product test page");
                            nextAllowedAt = now + 900L;
                        } else if (stateTimedOut(8_000L)) {
                            transition(State.WAIT_AD_DONE, "no product/live entry in test fixture");
                        }
                    }
                    break;

                case WAIT_PRODUCT_ENTRY:
                    AccessibilityNodeInfo product = findById(AutomationConfig.ID_PRODUCT_ENTRY);
                    if (product != null && clickNode(product)) {
                        transition(State.WAIT_ADD_TO_CART, "opened live product test page");
                        nextAllowedAt = now + 800L;
                    } else if (stateTimedOut(8_000L)) {
                        transition(State.BACK_TO_AD, "live product entry timeout");
                    }
                    break;

                case WAIT_ADD_TO_CART:
                    AccessibilityNodeInfo add = findById(AutomationConfig.ID_ADD_TO_CART);
                    if (add != null && clickNode(add)) {
                        FileLogger.log(this, "TEST ACTION: add_to_cart clicked");
                        transition(State.BACK_TO_AD, "cart action done");
                        nextAllowedAt = now + 700L;
                    } else if (stateTimedOut(8_000L)) {
                        transition(State.BACK_TO_AD, "add_to_cart timeout");
                    }
                    break;

                case BACK_TO_AD:
                    if (backStepsRemaining > 0) {
                        performGlobalAction(GLOBAL_ACTION_BACK);
                        FileLogger.log(this, "GLOBAL_BACK; remaining(before dec)=" + backStepsRemaining);
                        backStepsRemaining--;
                        nextAllowedAt = now + 650L;
                    } else {
                        transition(State.WAIT_AD_DONE, "returned to ad test page");
                    }
                    break;

                case WAIT_AD_DONE:
                    if (findById(AutomationConfig.ID_AD_COUNTDOWN_FINISHED) != null) {
                        transition(State.SWIPE_NEXT, "ad countdown complete");
                    } else if (stateTimedOut(120_000L)) {
                        beginRecovery("ad countdown timeout", null);
                    }
                    break;

                case SWIPE_NEXT:
                    swipeUp(() -> {
                        completedLoops++;
                        consecutiveErrors = 0;
                        FileLogger.log(this, "LOOP COMPLETE " + completedLoops + "/" + AutomationConfig.loopTarget(this));
                        if (AutomationConfig.screenshotEachLoop(this)) {
                            captureScreenshot("loop-" + completedLoops);
                        }
                        if (completedLoops >= AutomationConfig.loopTarget(this)) {
                            pauseAutomation("loop target reached");
                        } else {
                            AutomationConfig.setDemoCycle(this, completedLoops);
                            transition(State.WAIT_VIDEO_END, "next built-in short-video fixture");
                            launchTargetApp();
                            nextAllowedAt = System.currentTimeMillis() + 900L;
                            scheduleTick(1000L);
                        }
                    });
                    nextAllowedAt = now + 1500L;
                    break;

                case RECOVERING:
                    runRecoveryStep();
                    break;

                case PAUSED:
                default:
                    break;
            }
        } catch (Throwable t) {
            beginRecovery("tick exception", t);
        }

        updateOverlay();
        if (running) scheduleTick(350L);
    }

    private void transition(State next, String reason) {
        state = next;
        stateEnteredAt = System.currentTimeMillis();
        FileLogger.log(this, "STATE -> " + next + " :: " + reason);
        updateOverlay();
    }

    private boolean stateTimedOut(long ms) {
        return System.currentTimeMillis() - stateEnteredAt > ms;
    }

    private AccessibilityNodeInfo findById(String shortId) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        CharSequence pkg = root.getPackageName();
        if (pkg == null || !AutomationConfig.TARGET_PACKAGE.contentEquals(pkg)) return null;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(
                AutomationConfig.TARGET_PACKAGE + ":id/" + shortId);
        if (nodes == null || nodes.isEmpty()) return null;
        return nodes.get(0);
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        int depth = 0;
        while (n != null && depth++ < 6) {
            if (n.isClickable()) {
                boolean ok = n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                FileLogger.log(this, "CLICK id=" + node.getViewIdResourceName() + " ok=" + ok);
                return ok;
            }
            n = n.getParent();
        }
        FileLogger.log(this, "CLICK failed: no clickable ancestor id=" + node.getViewIdResourceName());
        return false;
    }

    private void swipeUp(Runnable onDone) {
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.graphics.Point size = new android.graphics.Point();
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect b = windowManager.getCurrentWindowMetrics().getBounds();
            size.x = b.width();
            size.y = b.height();
        } else {
            windowManager.getDefaultDisplay().getSize(size);
        }
        float x = size.x * 0.5f;
        float y1 = size.y * 0.78f;
        float y2 = size.y * 0.24f;
        Path path = new Path();
        path.moveTo(x, y1);
        path.lineTo(x, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 480);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                FileLogger.log(AutomationAccessibilityService.this, "SWIPE completed");
                if (onDone != null) onDone.run();
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                beginRecovery("swipe cancelled", null);
            }
        }, handler);
    }

    private void beginRecovery(String reason, Throwable t) {
        consecutiveErrors++;
        if (t == null) FileLogger.log(this, "RECOVERY begin: " + reason + " count=" + consecutiveErrors);
        else FileLogger.log(this, "RECOVERY begin: " + reason + " count=" + consecutiveErrors, t);
        captureScreenshot("error-" + consecutiveErrors);
        if (consecutiveErrors >= 4) {
            pauseAutomation("too many consecutive errors");
            return;
        }
        recoveryStep = 0;
        transition(State.RECOVERING, reason);
        nextAllowedAt = System.currentTimeMillis() + 500L;
    }

    private void runRecoveryStep() {
        long now = System.currentTimeMillis();
        switch (recoveryStep) {
            case 0:
            case 1:
                performGlobalAction(GLOBAL_ACTION_BACK);
                FileLogger.log(this, "RECOVERY back step=" + recoveryStep);
                recoveryStep++;
                nextAllowedAt = now + 700L;
                break;
            case 2:
                launchTargetApp();
                recoveryStep++;
                nextAllowedAt = now + 1500L;
                break;
            default:
                transition(State.WAIT_VIDEO_END, "recovery complete");
                nextAllowedAt = now + 800L;
                break;
        }
    }

    private boolean isTargetInstalled() {
        return true;
    }

    private void launchTargetApp() {
        Intent intent = new Intent(this, DemoVideoActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(intent);
            FileLogger.log(this, "Launch built-in test page cycle=" + AutomationConfig.demoCycle(this));
        } catch (Throwable t) {
            FileLogger.log(this, "Launch built-in test page failed", t);
        }
    }

    private void captureScreenshot(String label) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            FileLogger.log(this, "Screenshot skipped: requires API 30+");
            return;
        }
        Executor executor = getMainExecutor();
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult screenshot) {
                HardwareBuffer buffer = screenshot.getHardwareBuffer();
                Bitmap hardware = Bitmap.wrapHardwareBuffer(buffer, screenshot.getColorSpace());
                if (hardware == null) {
                    buffer.close();
                    FileLogger.log(AutomationAccessibilityService.this, "Screenshot wrap failed");
                    return;
                }
                Bitmap bitmap = hardware.copy(Bitmap.Config.ARGB_8888, false);
                buffer.close();
                if (bitmap == null) {
                    FileLogger.log(AutomationAccessibilityService.this, "Screenshot copy failed");
                    return;
                }
                saveBitmap(bitmap, label);
                bitmap.recycle();
            }

            @Override
            public void onFailure(int errorCode) {
                FileLogger.log(AutomationAccessibilityService.this, "Screenshot failure code=" + errorCode);
            }
        });
    }

    private void saveBitmap(Bitmap bitmap, String label) {
        try {
            File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (base == null) base = getFilesDir();
            File dir = new File(base, "AutomationQA/screenshots");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, fileTs.format(new Date()) + "-" + sanitize(label) + ".png");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            FileLogger.log(this, "Screenshot saved: " + file.getAbsolutePath());
        } catch (Throwable t) {
            FileLogger.log(this, "Screenshot save failed", t);
        }
    }

    private String sanitize(String s) {
        return s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private void scheduleTick(long delayMs) {
        handler.removeCallbacks(tickRunnable);
        handler.postDelayed(tickRunnable, Math.max(30L, delayMs));
    }

    private void showOverlayIfAllowed() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        box.setBackgroundColor(Color.argb(220, 32, 32, 32));

        overlayStatus = new TextView(this);
        overlayStatus.setTextColor(Color.WHITE);
        overlayStatus.setTextSize(12);
        overlayStatus.setTypeface(Typeface.MONOSPACE);
        box.addView(overlayStatus);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        overlayToggle = new Button(this);
        overlayToggle.setText("开始");
        overlayToggle.setOnClickListener(v -> {
            if (running) pauseAutomation("overlay");
            else startAutomation("overlay");
        });
        row.addView(overlayToggle, new LinearLayout.LayoutParams(dp(92), dp(48)));

        Button shot = new Button(this);
        shot.setText("截图");
        shot.setOnClickListener(v -> captureScreenshot("manual"));
        row.addView(shot, new LinearLayout.LayoutParams(dp(78), dp(48)));

        box.addView(row);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(10);
        lp.y = dp(120);

        final int[] downX = new int[1];
        final int[] downY = new int[1];
        final int[] startX = new int[1];
        final int[] startY = new int[1];
        overlayStatus.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX[0] = (int) e.getRawX();
                    downY[0] = (int) e.getRawY();
                    startX[0] = lp.x;
                    startY[0] = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = Math.max(0, startX[0] - ((int) e.getRawX() - downX[0]));
                    lp.y = Math.max(0, startY[0] + ((int) e.getRawY() - downY[0]));
                    wm.updateViewLayout(box, lp);
                    return true;
                default:
                    return true;
            }
        });

        try {
            wm.addView(box, lp);
            overlay = box;
            updateOverlay();
            FileLogger.log(this, "Overlay shown");
        } catch (Throwable t) {
            FileLogger.log(this, "Overlay failed", t);
        }
    }

    private void updateOverlay() {
        if (overlayStatus == null || overlayToggle == null) return;
        handler.post(() -> {
            overlayStatus.setText((running ? "RUN" : "PAUSE") + "  " + state + "\n" +
                    completedLoops + "/" + AutomationConfig.loopTarget(this));
            overlayToggle.setText(running ? "暂停" : "开始");
        });
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
        overlayToggle = null;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
