package com.example.autoqatool;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class DemoUi {
    private DemoUi() {}

    static LinearLayout page(Context c, String title, String subtitle) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = dp(c, 22);
        root.setPadding(p, p, p, p);

        TextView h = new TextView(c);
        h.setText(title);
        h.setTextSize(26);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setGravity(Gravity.CENTER);
        root.addView(h, full());

        TextView s = new TextView(c);
        s.setText(subtitle);
        s.setTextSize(15);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, dp(c, 14), 0, dp(c, 22));
        root.addView(s, full());
        return root;
    }

    static TextView text(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextSize(18);
        v.setGravity(Gravity.CENTER);
        v.setPadding(12, 18, 12, 18);
        return v;
    }

    static Button button(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextSize(17);
        LinearLayout.LayoutParams lp = full();
        lp.topMargin = dp(c, 12);
        b.setLayoutParams(lp);
        return b;
    }

    static LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
