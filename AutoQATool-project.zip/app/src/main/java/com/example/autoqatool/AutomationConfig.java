package com.example.autoqatool;

import android.content.Context;
import android.content.SharedPreferences;

public final class AutomationConfig {
    private AutomationConfig() {}

    public static final String PREFS = "auto_qa_prefs";

    // Zero-code edition: automation is permanently scoped to this APK itself.
    public static final String TARGET_PACKAGE = "com.example.autoqatool";

    public static final String ID_VIDEO_FINISHED = "video_finished";
    public static final String ID_ENTER_LIVE = "enter_live_room";
    public static final String ID_PRODUCT_ENTRY = "product_entry";
    public static final String ID_AD_PRODUCT_LINK = "ad_product_link";
    public static final String ID_ADD_TO_CART = "add_to_cart";
    public static final String ID_AD_COUNTDOWN_FINISHED = "ad_countdown_finished";

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int loopTarget(Context c) {
        return Math.max(1, prefs(c).getInt("loop_target", 20));
    }

    public static boolean screenshotEachLoop(Context c) {
        return prefs(c).getBoolean("screenshot_each_loop", false);
    }

    public static boolean autoStart(Context c) {
        return prefs(c).getBoolean("auto_start", false);
    }

    public static int demoCycle(Context c) {
        return Math.max(0, prefs(c).getInt("demo_cycle", 0));
    }

    public static void setDemoCycle(Context c, int cycle) {
        prefs(c).edit().putInt("demo_cycle", Math.max(0, cycle)).apply();
    }
}
