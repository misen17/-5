package com.example.channelsassistant;

import android.content.Context;
import android.provider.Settings;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ActivationManager {
    private ActivationManager() {}

    private static final String KEY_ACTIVATION = "activation_code";

    // Public key only. The matching private key stays in the separate admin generator HTML.
    private static final String PUBLIC_KEY_B64 =
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxIzQPFnj3c0EztL+kzr3dPz0l0cVsbly2o3ebQgJ3ntPwAyK6Z8ojVTUgnkVKkAbAGqtQsj5PQ96xQpsWF78AHEvtpEnw+8+FYRbKWcfq090KjRnVC5sDqz3oDi/+RHQ00WPbjA0hcN0jM6CKbrsQgJ0lVasE3+SDssVuEqQkOmT0iJ7iKIBtTNXs/CPVHpIW8DYb715dZruslXn8v5bxUgV+Q7M80tWWfng1Jd8VjBXu5EpdG+4GNrsIJy+FquXGaHRdbl5TVfXdbu2A014/Y1QZdtv+nlRb3ztwgU69/NhB2aVe13R0Ub/b4a5gve+hx/duhUIR2HM0pd31I6m/wIDAQAB";

    public static String deviceCode(Context c) {
        try {
            String androidId = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null) androidId = "unknown";
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest((androidId + "|" + c.getPackageName()).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format(Locale.US, "%02X", digest[i]));
            String raw = sb.toString();
            return raw.substring(0, 4) + "-" + raw.substring(4, 8) + "-" +
                    raw.substring(8, 12) + "-" + raw.substring(12, 16);
        } catch (Exception e) {
            return "DEVICE-UNKNOWN";
        }
    }

    public static boolean activate(Context c, String code) {
        Verification v = verify(c, code);
        if (!v.valid) return false;
        AutomationConfig.prefs(c).edit().putString(KEY_ACTIVATION, code.trim()).apply();
        return true;
    }

    public static boolean isActivated(Context c) {
        String code = AutomationConfig.prefs(c).getString(KEY_ACTIVATION, "");
        return verify(c, code).valid;
    }

    public static Verification current(Context c) {
        String code = AutomationConfig.prefs(c).getString(KEY_ACTIVATION, "");
        return verify(c, code);
    }

    public static Verification verify(Context c, String code) {
        if (code == null || code.trim().isEmpty()) return Verification.fail("未输入激活码");
        try {
            String compact = code.replace("\n", "").replace("\r", "").replace(" ", "").trim();
            String[] parts = compact.split("\\.");
            if (parts.length != 2) return Verification.fail("激活码格式不正确");

            byte[] payloadBytes = Base64.decode(parts[0], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            byte[] sigBytes = Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);

            byte[] pubBytes = Base64.decode(PUBLIC_KEY_B64, Base64.DEFAULT);
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(pubBytes));
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initVerify(publicKey);
            signature.update(payloadBytes);
            if (!signature.verify(sigBytes)) return Verification.fail("激活码签名无效");

            JSONObject obj = new JSONObject(new String(payloadBytes, StandardCharsets.UTF_8));
            if (obj.optInt("v", 0) != 1) return Verification.fail("激活码版本不支持");
            String device = obj.optString("device", "");
            long exp = obj.optLong("exp", -1L);
            if (device.isEmpty()) return Verification.fail("激活码缺少设备信息");
            if (!("*".equals(device) || deviceCode(c).equalsIgnoreCase(device))) {
                return Verification.fail("激活码不是这台设备的");
            }
            long now = System.currentTimeMillis() / 1000L;
            if (exp > 0 && now > exp) return Verification.fail("激活码已到期");
            return Verification.ok(device, exp);
        } catch (Exception e) {
            return Verification.fail("激活码无法识别");
        }
    }

    public static String statusText(Context c) {
        Verification v = current(c);
        if (!v.valid) return "未激活：" + v.message;
        if (v.exp == 0L) return "已激活：永久";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA);
        return "已激活至：" + sdf.format(new Date(v.exp * 1000L));
    }

    public static final class Verification {
        public final boolean valid;
        public final String message;
        public final String device;
        public final long exp;

        private Verification(boolean valid, String message, String device, long exp) {
            this.valid = valid;
            this.message = message;
            this.device = device;
            this.exp = exp;
        }

        static Verification ok(String device, long exp) {
            return new Verification(true, "有效", device, exp);
        }

        static Verification fail(String message) {
            return new Verification(false, message, "", -1L);
        }
    }
}
