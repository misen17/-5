package com.example.channelsassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.List;
import java.util.concurrent.Executor;

public class ChannelsAccessibilityService extends AccessibilityService {
    private static volatile ChannelsAccessibilityService instance;

    private enum ActionType {
        NONE,
        ENTER_LIVE,
        OPEN_PRODUCT,
        ADD_TO_CART,
        RESERVE,
        LIKE,
        NEXT_VIDEO
    }

    private static final String[][] INCLUDE = new String[][] {
            {},
            {"进入直播间", "去直播间", "直播中"},
            {"商品橱窗", "查看商品", "商品卡", "去看看", "去购买", "购物袋"},
            {"加入购物车", "加购物车"},
            {"预约直播", "立即预约", "预约"},
            {"点赞"},
            {}
    };

    private static final String[][] EXCLUDE = new String[][] {
            {}, {}, {}, {},
            {"已预约", "取消预约"},
            {"已点赞", "取消点赞"},
            {}
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tickRunnable = this::tick;
    private final SimpleDateFormat fileTs = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US);

    private boolean running = false;
    private boolean checkpointPaused = false;
    private int confirmedInBatch = 0;
    private int confirmedTotal = 0;
    private long videoTimerStartedAt = 0L;
    private long suppressUntil = 0L;
    private long lastWindowChangeAt = 0L;
    private String lastWindowClass = "";

    // Account lock: after every NEXT_VIDEO swipe this is cleared.
    // A new video must visibly expose one of the configured target account names
    // before any detection/action is allowed.
    private boolean targetLockGranted = false;
    private String lockedTargetAccount = "";

    private ActionType pendingAction = ActionType.NONE;
    private String pendingLabel = "";

    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private Button confirmButton;
    private Button skipButton;
    private Button pauseButton;

    public static ChannelsAccessibilityService getInstance() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        FileLogger.log(this, "Accessibility service connected; package scope=" + AutomationConfig.WECHAT_PACKAGE);
        showOverlayIfAllowed();
        if (ActivationManager.isActivated(this) && AutomationConfig.autoStart(this)) {
            handler.postDelayed(() -> startAssistant("service-reconnect"), 1200L);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence cls = event.getClassName();
            lastWindowClass = cls == null ? "" : cls.toString();
            lastWindowChangeAt = System.currentTimeMillis();
            if (running && pendingAction == ActionType.NONE) {
                videoTimerStartedAt = System.currentTimeMillis();
            }
        }
        if (running) scheduleTick(120L);
    }

    @Override
    public void onInterrupt() {
        pauseAssistant("interrupt");
    }

    @Override
    public void onDestroy() {
        removeOverlay();
        handler.removeCallbacksAndMessages(null);
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public void startAssistantFromUi() {
        startAssistant("main-ui");
    }

    public void pauseAssistant(String reason) {
        running = false;
        pendingAction = ActionType.NONE;
        pendingLabel = "";
        handler.removeCallbacks(tickRunnable);
        FileLogger.log(this, "PAUSE reason=" + reason + " batch=" + confirmedInBatch + " total=" + confirmedTotal);
        updateOverlay();
    }

    public String getPublicStatus() {
        if (!ActivationManager.isActivated(this)) return "未激活";
        if (checkpointPaused) return "40次检查点暂停";
        String lock = targetLockGranted ? ("已锁定:" + lockedTargetAccount) : "等待锁定账号";
        return (running ? "识别中" : "暂停") + " / " + lock + " / " + actionName(pendingAction) +
                " / 本组" + confirmedInBatch + "/" + AutomationConfig.CHECKPOINT_LIMIT;
    }

    private void startAssistant(String reason) {
        if (!ActivationManager.isActivated(this)) {
            running = false;
            pendingAction = ActionType.NONE;
            pendingLabel = "软件未激活或激活码已到期";
            FileLogger.log(this, "START blocked: activation invalid");
            showOverlayIfAllowed();
            updateOverlay();
            return;
        }
        if (!AutomationConfig.hasTargetAccounts(this)) {
            running = false;
            pendingAction = ActionType.NONE;
            pendingLabel = "请先在主界面填写至少一个锁定账号";
            FileLogger.log(this, "START blocked: no target accounts configured");
            updateOverlay();
            return;
        }
        checkpointPaused = false;
        running = true;
        targetLockGranted = false;
        lockedTargetAccount = "";
        pendingAction = ActionType.NONE;
        pendingLabel = "";
        if (videoTimerStartedAt == 0L) videoTimerStartedAt = System.currentTimeMillis();
        FileLogger.log(this, "START reason=" + reason);
        showOverlayIfAllowed();
        scheduleTick(200L);
        updateOverlay();
    }

    private void continueAfterCheckpoint() {
        checkpointPaused = false;
        confirmedInBatch = 0;
        running = true;
        pendingAction = ActionType.NONE;
        pendingLabel = "";
        targetLockGranted = false;
        lockedTargetAccount = "";
        videoTimerStartedAt = System.currentTimeMillis();
        suppressUntil = System.currentTimeMillis() + 500L;
        FileLogger.log(this, "CHECKPOINT continued; total=" + confirmedTotal);
        scheduleTick(250L);
        updateOverlay();
    }

    private void tick() {
        if (!running || checkpointPaused) return;
        if (!ActivationManager.isActivated(this)) {
            running = false;
            pendingAction = ActionType.NONE;
            pendingLabel = "激活码已失效，请重新激活";
            FileLogger.log(this, "AUTO STOP: activation invalid/expired");
            updateOverlay();
            return;
        }
        long now = System.currentTimeMillis();
        if (now < suppressUntil) {
            scheduleTick(300L);
            return;
        }
        if (pendingAction != ActionType.NONE) {
            updateOverlay();
            scheduleTick(500L);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            setInfoOnly("等待微信页面");
            scheduleTick(600L);
            return;
        }
        CharSequence pkg = root.getPackageName();
        if (pkg == null || !AutomationConfig.WECHAT_PACKAGE.contentEquals(pkg)) {
            setInfoOnly("等待进入微信 / 视频号");
            scheduleTick(700L);
            return;
        }

        // Strict account whitelist gate. When the current video exposes one of the
        // configured account names, grant a temporary lock for linked product/live
        // pages. The lock is always cleared after moving to the next video.
        String visibleTarget = detectVisibleTargetAccount(root);
        if (!visibleTarget.isEmpty()) {
            if (!targetLockGranted || !visibleTarget.equals(lockedTargetAccount)) {
                FileLogger.log(this, "TARGET_LOCK granted account=" + visibleTarget);
                videoTimerStartedAt = now;
            }
            targetLockGranted = true;
            lockedTargetAccount = visibleTarget;
        }

        if (!targetLockGranted) {
            pendingAction = ActionType.NONE;
            pendingLabel = "非锁定账号 / 等待目标账号";
            setInfoOnly("非锁定账号，不执行任何动作");
            scheduleTick(600L);
            return;
        }

        Candidate c;
        c = findCandidate(root, ActionType.ADD_TO_CART);
        if (c == null) c = findCandidate(root, ActionType.RESERVE);
        if (c == null) c = findCandidate(root, ActionType.ENTER_LIVE);
        if (c == null) c = findCandidate(root, ActionType.OPEN_PRODUCT);
        if (c == null) c = findCandidate(root, ActionType.LIKE);

        if (c != null) {
            pendingAction = c.type;
            pendingLabel = c.label;
            FileLogger.log(this, "DETECTED action=" + c.type + " label=" + c.label + " window=" + lastWindowClass);
            updateOverlay();
            scheduleTick(500L);
            return;
        }

        long elapsed = now - videoTimerStartedAt;
        if (elapsed >= AutomationConfig.watchSeconds(this) * 1000L) {
            pendingAction = ActionType.NEXT_VIDEO;
            pendingLabel = "已达到 " + AutomationConfig.watchSeconds(this) + " 秒观察时间";
            FileLogger.log(this, "DETECTED action=NEXT_VIDEO afterMs=" + elapsed);
            updateOverlay();
        } else {
            setInfoOnly("识别中 · 已观察 " + Math.max(0, elapsed / 1000L) + " 秒");
        }
        scheduleTick(500L);
    }

    private void confirmPending() {
        if (!ActivationManager.isActivated(this)) {
            running = false;
            pendingAction = ActionType.NONE;
            pendingLabel = "激活码已失效，请重新激活";
            updateOverlay();
            return;
        }
        if (checkpointPaused) {
            continueAfterCheckpoint();
            return;
        }
        if (!running || pendingAction == ActionType.NONE) return;

        final ActionType action = pendingAction;
        final String label = pendingLabel;

        if (action == ActionType.NEXT_VIDEO) {
            swipeUp(() -> onConfirmedAction(action, label, true));
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        Candidate fresh = root == null ? null : findCandidate(root, action);
        if (fresh == null) {
            FileLogger.log(this, "CONFIRM failed: target disappeared action=" + action + " oldLabel=" + label);
            pendingAction = ActionType.NONE;
            pendingLabel = "目标已消失，请重新识别";
            suppressUntil = System.currentTimeMillis() + 1000L;
            updateOverlay();
            return;
        }

        boolean ok = clickNode(fresh.node);
        FileLogger.log(this, "CONFIRM action=" + action + " label=" + fresh.label + " clickOk=" + ok);
        onConfirmedAction(action, fresh.label, ok);
    }

    private void onConfirmedAction(ActionType action, String label, boolean ok) {
        if (!ok) {
            pendingAction = ActionType.NONE;
            pendingLabel = "执行失败，请重新识别";
            suppressUntil = System.currentTimeMillis() + 1200L;
            updateOverlay();
            return;
        }

        confirmedInBatch++;
        confirmedTotal++;
        if (AutomationConfig.screenshotOnAction(this)) {
            captureScreenshot(action.name().toLowerCase(Locale.US) + "-" + confirmedTotal);
        }

        pendingAction = ActionType.NONE;
        pendingLabel = "";
        suppressUntil = System.currentTimeMillis() + 1300L;
        if (action == ActionType.NEXT_VIDEO) {
            // Never carry authorization to the next video. The next page must show
            // one of the configured target account names again.
            targetLockGranted = false;
            lockedTargetAccount = "";
            videoTimerStartedAt = System.currentTimeMillis();
            FileLogger.log(this, "TARGET_LOCK cleared after NEXT_VIDEO");
        } else if (action == ActionType.ENTER_LIVE || action == ActionType.OPEN_PRODUCT) {
            videoTimerStartedAt = System.currentTimeMillis();
        }

        if (confirmedInBatch >= AutomationConfig.CHECKPOINT_LIMIT) {
            running = false;
            checkpointPaused = true;
            FileLogger.log(this, "CHECKPOINT reached 40; total=" + confirmedTotal);
        }
        updateOverlay();
        if (running) scheduleTick(500L);
    }

    private void skipPending() {
        if (pendingAction == ActionType.NONE) return;
        FileLogger.log(this, "SKIP action=" + pendingAction + " label=" + pendingLabel);
        if (pendingAction == ActionType.NEXT_VIDEO) {
            videoTimerStartedAt = System.currentTimeMillis();
        }
        pendingAction = ActionType.NONE;
        pendingLabel = "已跳过，继续识别";
        suppressUntil = System.currentTimeMillis() + 5000L;
        updateOverlay();
        scheduleTick(5200L);
    }

    private String detectVisibleTargetAccount(AccessibilityNodeInfo root) {
        List<String> targets = AutomationConfig.targetAccounts(this);
        if (targets.isEmpty() || root == null) return "";

        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        int visited = 0;
        while (!q.isEmpty() && visited++ < 900) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            String label = normalizeAccountText(nodeLabel(n));
            if (!label.isEmpty()) {
                for (String target : targets) {
                    String nt = normalizeAccountText(target);
                    if (nt.isEmpty()) continue;
                    // Keep matching deliberately strict so a nickname merely mentioned
                    // inside a long caption does not unlock another creator's video.
                    boolean exact = label.equals(nt) || label.equals("@" + nt);
                    boolean compactDecorated = label.length() <= nt.length() + 16 &&
                            (label.startsWith(nt + "|") || label.startsWith("@" + nt + "|") ||
                             label.endsWith("|" + nt) || label.endsWith("|@" + nt));
                    if (exact || compactDecorated) {
                        return target;
                    }
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        return "";
    }

    private String normalizeAccountText(String s) {
        if (s == null) return "";
        return s.replace(" ", "")
                .replace("\n", "")
                .replace("\t", "")
                .trim();
    }

    private Candidate findCandidate(AccessibilityNodeInfo root, ActionType type) {
        if (type == ActionType.NONE || type == ActionType.NEXT_VIDEO) return null;
        String[] includes = INCLUDE[type.ordinal()];
        String[] excludes = EXCLUDE[type.ordinal()];

        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        int visited = 0;
        Candidate fallback = null;

        while (!q.isEmpty() && visited++ < 700) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (n == null) continue;
            String label = nodeLabel(n);
            if (!label.isEmpty() && containsAny(label, includes) && !containsAny(label, excludes)) {
                AccessibilityNodeInfo clickable = clickableAncestor(n);
                if (clickable != null && clickable.isVisibleToUser() && clickable.isEnabled()) {
                    Candidate c = new Candidate(type, label, n);
                    if (isStrongMatch(label, type)) return c;
                    if (fallback == null) fallback = c;
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        return fallback;
    }

    private boolean isStrongMatch(String label, ActionType type) {
        String s = label.replace(" ", "");
        switch (type) {
            case ADD_TO_CART:
                return s.contains("加入购物车") || s.equals("加购物车");
            case ENTER_LIVE:
                return s.contains("进入直播间") || s.contains("去直播间");
            case RESERVE:
                return s.contains("预约直播") || s.contains("立即预约") || s.equals("预约");
            case LIKE:
                return s.equals("点赞") || s.endsWith("点赞");
            case OPEN_PRODUCT:
                return s.contains("商品橱窗") || s.contains("查看商品") || s.contains("商品卡") || s.equals("购物袋");
            default:
                return false;
        }
    }

    private String nodeLabel(AccessibilityNodeInfo n) {
        StringBuilder sb = new StringBuilder();
        if (n.getText() != null) sb.append(n.getText());
        if (n.getContentDescription() != null) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(n.getContentDescription());
        }
        return sb.toString().trim();
    }

    private boolean containsAny(String haystack, String[] needles) {
        if (needles == null || needles.length == 0) return false;
        for (String s : needles) {
            if (s != null && !s.isEmpty() && haystack.contains(s)) return true;
        }
        return false;
    }

    private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 7 && n != null; i++) {
            if (n.isClickable()) return n;
            n = n.getParent();
        }
        return null;
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = clickableAncestor(node);
        if (n == null) return false;
        try {
            return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        } catch (Throwable t) {
            FileLogger.log(this, "clickNode exception", t);
            return false;
        }
    }

    private void swipeUp(Runnable onDone) {
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.graphics.Point size = new android.graphics.Point();
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect b = windowManager.getCurrentWindowMetrics().getBounds();
            size.x = b.width();
            size.y = b.height();
        } else {
            windowManager.getDefaultDisplay().getSize(size);
        }
        float x = size.x * 0.5f;
        float y1 = size.y * 0.78f;
        float y2 = size.y * 0.24f;
        Path path = new Path();
        path.moveTo(x, y1);
        path.lineTo(x, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 480);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                FileLogger.log(ChannelsAccessibilityService.this, "CONFIRMED SWIPE completed");
                if (onDone != null) onDone.run();
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                FileLogger.log(ChannelsAccessibilityService.this, "CONFIRMED SWIPE cancelled; waiting for another confirmation");
            }
        }, handler);
    }

    private void setInfoOnly(String text) {
        if (pendingAction == ActionType.NONE) pendingLabel = text;
        updateOverlay();
    }

    private String actionName(ActionType t) {
        switch (t) {
            case ENTER_LIVE: return "进入直播间";
            case OPEN_PRODUCT: return "打开商品";
            case ADD_TO_CART: return "加入购物车";
            case RESERVE: return "预约";
            case LIKE: return "点赞";
            case NEXT_VIDEO: return "下一条";
            default: return "无待确认动作";
        }
    }

    private String actionPrompt(ActionType t) {
        switch (t) {
            case ENTER_LIVE: return "发现直播入口。确认后点击进入直播间。";
            case OPEN_PRODUCT: return "发现商品入口。确认后打开商品页面。";
            case ADD_TO_CART: return "发现“加入购物车”。确认后执行一次加购。";
            case RESERVE: return "发现预约按钮。确认后执行一次预约。";
            case LIKE: return "发现点赞按钮。确认后执行一次点赞。";
            case NEXT_VIDEO: return "达到观察时间。确认后上滑进入下一条。";
            default: return pendingLabel == null ? "识别中" : pendingLabel;
        }
    }

    private void showOverlayIfAllowed() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        box.setBackgroundColor(Color.argb(225, 30, 30, 30));

        overlayStatus = new TextView(this);
        overlayStatus.setTextColor(Color.WHITE);
        overlayStatus.setTextSize(12);
        overlayStatus.setTypeface(Typeface.MONOSPACE);
        overlayStatus.setMaxWidth(dp(300));
        box.addView(overlayStatus);

        confirmButton = new Button(this);
        confirmButton.setText("确认执行");
        confirmButton.setOnClickListener(v -> confirmPending());
        box.addView(confirmButton, new LinearLayout.LayoutParams(dp(220), dp(48)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        skipButton = new Button(this);
        skipButton.setText("跳过");
        skipButton.setOnClickListener(v -> skipPending());
        row.addView(skipButton, new LinearLayout.LayoutParams(dp(105), dp(46)));

        pauseButton = new Button(this);
        pauseButton.setText("暂停");
        pauseButton.setOnClickListener(v -> {
            if (checkpointPaused) continueAfterCheckpoint();
            else if (running) pauseAssistant("overlay");
            else startAssistant("overlay");
        });
        row.addView(pauseButton, new LinearLayout.LayoutParams(dp(105), dp(46)));
        box.addView(row);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(10);
        lp.y = dp(120);

        final int[] downX = new int[1];
        final int[] downY = new int[1];
        final int[] startX = new int[1];
        final int[] startY = new int[1];
        overlayStatus.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX[0] = (int) e.getRawX();
                    downY[0] = (int) e.getRawY();
                    startX[0] = lp.x;
                    startY[0] = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = Math.max(0, startX[0] - ((int) e.getRawX() - downX[0]));
                    lp.y = Math.max(0, startY[0] + ((int) e.getRawY() - downY[0]));
                    wm.updateViewLayout(box, lp);
                    return true;
                default:
                    return true;
            }
        });

        try {
            wm.addView(box, lp);
            overlay = box;
            updateOverlay();
            FileLogger.log(this, "Overlay shown");
        } catch (Throwable t) {
            FileLogger.log(this, "Overlay failed", t);
        }
    }

    private void updateOverlay() {
        if (overlayStatus == null || confirmButton == null || skipButton == null || pauseButton == null) return;
        handler.post(() -> {
            if (checkpointPaused) {
                overlayStatus.setText("已完成本组40次\n请人员确认后继续\n累计：" + confirmedTotal);
                confirmButton.setVisibility(View.GONE);
                skipButton.setVisibility(View.GONE);
                pauseButton.setText("继续下一组");
                return;
            }

            String head = running ? "识别中" : "已暂停";
            String action = pendingAction == ActionType.NONE ? "无待确认动作" : actionName(pendingAction);
            String detail = actionPrompt(pendingAction);
            if (pendingAction == ActionType.NONE && pendingLabel != null && !pendingLabel.isEmpty()) detail = pendingLabel;
            overlayStatus.setText(head + " · 本组 " + confirmedInBatch + "/40\n" +
                    "待确认：" + action + "\n" + detail +
                    (lastWindowClass.isEmpty() ? "" : "\n页面：" + trim(lastWindowClass, 36)));

            boolean hasPending = running && pendingAction != ActionType.NONE;
            confirmButton.setVisibility(hasPending ? View.VISIBLE : View.GONE);
            skipButton.setVisibility(hasPending ? View.VISIBLE : View.GONE);
            confirmButton.setText("确认执行 · " + actionName(pendingAction));
            pauseButton.setText(running ? "暂停" : "继续");
        });
    }

    private String trim(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(s.length() - max);
    }

    private void captureScreenshot(String label) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            FileLogger.log(this, "Screenshot skipped: requires API 30+");
            return;
        }
        Executor executor = getMainExecutor();
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult screenshot) {
                HardwareBuffer buffer = screenshot.getHardwareBuffer();
                Bitmap hardware = Bitmap.wrapHardwareBuffer(buffer, screenshot.getColorSpace());
                if (hardware == null) {
                    buffer.close();
                    return;
                }
                Bitmap bitmap = hardware.copy(Bitmap.Config.ARGB_8888, false);
                buffer.close();
                if (bitmap == null) return;
                saveBitmap(bitmap, label);
                bitmap.recycle();
            }

            @Override
            public void onFailure(int errorCode) {
                FileLogger.log(ChannelsAccessibilityService.this, "Screenshot failure code=" + errorCode);
            }
        });
    }

    private void saveBitmap(Bitmap bitmap, String label) {
        try {
            File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (base == null) base = getFilesDir();
            File dir = new File(base, "ChannelsAssist/screenshots");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, fileTs.format(new Date()) + "-" + sanitize(label) + ".png");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            FileLogger.log(this, "Screenshot saved: " + file.getAbsolutePath());
        } catch (Throwable t) {
            FileLogger.log(this, "Screenshot save failed", t);
        }
    }

    private String sanitize(String s) {
        return s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private void scheduleTick(long delayMs) {
        handler.removeCallbacks(tickRunnable);
        handler.postDelayed(tickRunnable, Math.max(50L, delayMs));
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
        confirmButton = null;
        skipButton = null;
        pauseButton = null;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class Candidate {
        final ActionType type;
        final String label;
        final AccessibilityNodeInfo node;

        Candidate(ActionType type, String label, AccessibilityNodeInfo node) {
            this.type = type;
            this.label = label;
            this.node = node;
        }
    }
}
