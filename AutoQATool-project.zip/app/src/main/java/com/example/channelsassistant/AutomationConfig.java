package com.example.channelsassistant;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public final class AutomationConfig {
    private AutomationConfig() {}

    public static final String PREFS = "channels_assist_prefs";
    public static final String WECHAT_PACKAGE = "com.tencent.mm";
    public static final int CHECKPOINT_LIMIT = 40;

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int watchSeconds(Context c) {
        int v = prefs(c).getInt("watch_seconds", 15);
        return Math.max(5, Math.min(v, 600));
    }

    public static boolean screenshotOnAction(Context c) {
        return prefs(c).getBoolean("screenshot_on_action", true);
    }

    public static boolean autoStart(Context c) {
        return prefs(c).getBoolean("auto_start", false);
    }

    public static String targetAccount1(Context c) {
        return prefs(c).getString("target_account_1", "").trim();
    }

    public static String targetAccount2(Context c) {
        return prefs(c).getString("target_account_2", "").trim();
    }

    public static List<String> targetAccounts(Context c) {
        ArrayList<String> out = new ArrayList<>();
        String a = targetAccount1(c);
        String b = targetAccount2(c);
        if (!a.isEmpty()) out.add(a);
        if (!b.isEmpty() && !b.equals(a)) out.add(b);
        return out;
    }

    public static boolean hasTargetAccounts(Context c) {
        return !targetAccounts(c).isEmpty();
    }
}
