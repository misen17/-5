package com.example.channelsassistant;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class FileLogger {
    private static final String TAG = "ChannelsAssist";
    private static final SimpleDateFormat DAY = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final SimpleDateFormat TS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

    private FileLogger() {}

    public static synchronized void log(Context context, String message) {
        Log.i(TAG, message);
        try {
            File base = context.getExternalFilesDir(null);
            if (base == null) base = context.getFilesDir();
            File dir = new File(base, "ChannelsAssist/logs");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "assist-" + DAY.format(new Date()) + ".log");
            try (FileWriter fw = new FileWriter(file, true)) {
                fw.write(TS.format(new Date()) + "  " + message + "\n");
            }
        } catch (Throwable t) {
            Log.e(TAG, "log write failed", t);
        }
    }

    public static synchronized void log(Context context, String message, Throwable error) {
        log(context, message + " :: " + error);
        try {
            File base = context.getExternalFilesDir(null);
            if (base == null) base = context.getFilesDir();
            File dir = new File(base, "ChannelsAssist/logs");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "assist-" + DAY.format(new Date()) + ".log");
            try (PrintWriter pw = new PrintWriter(new FileWriter(file, true))) {
                error.printStackTrace(pw);
            }
        } catch (Throwable ignored) {}
    }

    public static String basePath(Context context) {
        File base = context.getExternalFilesDir(null);
        if (base == null) base = context.getFilesDir();
        return new File(base, "ChannelsAssist").getAbsolutePath();
    }
}
