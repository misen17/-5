package com.example.channelsassistant;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText targetAccount1;
    private EditText targetAccount2;
    private EditText watchSeconds;
    private CheckBox screenshots;
    private CheckBox autoStart;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        renderInitialScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void renderInitialScreen() {
        if (ActivationManager.isActivated(this)) {
            setContentView(buildMainUi());
            loadPrefs();
            refreshStatus();
        } else {
            setContentView(buildActivationUi(false));
        }
    }

    private View buildActivationUi(boolean allowBack) {
        int p = dp(18);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("视频号辅助识别 · 软件激活");
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        body.addView(title);

        TextView intro = new TextView(this);
        intro.setText("本软件必须输入有效激活码后才能使用。\n\n把下面的设备码发给管理员，管理员使用独立的“激活码管理器”生成激活码。激活码可以设置有效天数，也可以绑定本机。\n\n设备码：");
        intro.setTextSize(15);
        intro.setPadding(0, dp(12), 0, dp(8));
        body.addView(intro);

        final String deviceCode = ActivationManager.deviceCode(this);
        TextView device = new TextView(this);
        device.setText(deviceCode);
        device.setTextSize(22);
        device.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        device.setPadding(dp(8), dp(10), dp(8), dp(10));
        body.addView(device);

        body.addView(button("复制设备码", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("device-code", deviceCode));
            toast("设备码已复制");
        }));

        TextView current = new TextView(this);
        current.setText("当前状态：" + ActivationManager.statusText(this));
        current.setTextSize(14);
        current.setPadding(0, dp(14), 0, dp(6));
        body.addView(current);

        EditText codeInput = new EditText(this);
        codeInput.setHint("把管理员生成的激活码粘贴到这里");
        codeInput.setMinLines(4);
        codeInput.setGravity(android.view.Gravity.TOP);
        codeInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        body.addView(codeInput);

        body.addView(button("立即激活", v -> {
            String code = codeInput.getText().toString().trim();
            ActivationManager.Verification vr = ActivationManager.verify(this, code);
            if (!vr.valid) {
                toast(vr.message);
                current.setText("当前状态：未激活 - " + vr.message);
                return;
            }
            if (ActivationManager.activate(this, code)) {
                toast("激活成功");
                setContentView(buildMainUi());
                loadPrefs();
                refreshStatus();
            }
        }));

        if (allowBack && ActivationManager.isActivated(this)) {
            body.addView(button("返回主界面", v -> {
                setContentView(buildMainUi());
                loadPrefs();
                refreshStatus();
            }));
        }

        TextView note = new TextView(this);
        note.setText("说明：\n• 激活码默认可绑定当前设备。\n• 到期后软件会自动停止识别和执行。\n• 永久码不会自动到期。\n• 激活码管理器请只由管理员保管，不要上传到公开 GitHub 仓库。\n• 更换手机后设备码会变化，需要重新生成激活码。");
        note.setTextSize(13);
        note.setPadding(0, dp(16), 0, dp(40));
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        return scroll;
    }

    private View buildMainUi() {
        int p = dp(18);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("视频号辅助识别 · 账号锁定版");
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        body.addView(title);

        TextView activation = new TextView(this);
        activation.setText("授权状态：" + ActivationManager.statusText(this) + "\n设备码：" + ActivationManager.deviceCode(this));
        activation.setTextSize(14);
        activation.setPadding(0, dp(10), 0, dp(4));
        body.addView(activation);
        body.addView(button("续期 / 更换激活码", v -> setContentView(buildActivationUi(true))));

        TextView intro = new TextView(this);
        intro.setText("先填写1个或2个你们自己的视频号昵称。软件只有在当前页面识别到锁定账号后，才会进入识别状态。上滑到下一条后会立即清除账号授权，必须重新识别到锁定账号才继续，避免误跑到其他账号。\n\n真正的互动点击和上滑仍然需要在悬浮窗里人工确认。累计执行40次后强制暂停。");
        intro.setTextSize(15);
        intro.setPadding(0, dp(12), 0, dp(16));
        body.addView(intro);

        TextView accountLabel = new TextView(this);
        accountLabel.setText("锁定视频号账号（请填写视频里实际显示的完整昵称）");
        accountLabel.setTypeface(Typeface.DEFAULT_BOLD);
        body.addView(accountLabel);

        targetAccount1 = new EditText(this);
        targetAccount1.setHint("账号1（必填，例如：鸿锦星漫官方）");
        targetAccount1.setSingleLine(true);
        body.addView(targetAccount1);

        targetAccount2 = new EditText(this);
        targetAccount2.setHint("账号2（选填）");
        targetAccount2.setSingleLine(true);
        body.addView(targetAccount2);

        TextView lockNote = new TextView(this);
        lockNote.setText("账号未匹配时：不识别商品、不执行互动、不提示下一条；悬浮窗会显示“非锁定账号/等待目标账号”。");
        lockNote.setTextSize(13);
        lockNote.setPadding(0, dp(4), 0, dp(12));
        body.addView(lockNote);

        TextView l1 = new TextView(this);
        l1.setText("无其他可识别动作时，多少秒后提示“下一条”");
        body.addView(l1);

        watchSeconds = new EditText(this);
        watchSeconds.setInputType(InputType.TYPE_CLASS_NUMBER);
        watchSeconds.setSingleLine(true);
        body.addView(watchSeconds);

        screenshots = new CheckBox(this);
        screenshots.setText("每次确认执行后自动截图");
        body.addView(screenshots);

        autoStart = new CheckBox(this);
        autoStart.setText("服务重连后自动进入识别状态");
        body.addView(autoStart);

        body.addView(button("保存配置", v -> savePrefs()));
        body.addView(button("1. 授予悬浮窗权限", v -> openOverlayPermission()));
        body.addView(button("2. 开启无障碍辅助服务", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        body.addView(button("3. 打开微信", v -> openWeChat()));
        body.addView(button("开始识别", v -> {
            if (!ActivationManager.isActivated(this)) {
                toast("激活码已失效，请重新激活");
                setContentView(buildActivationUi(false));
                return;
            }
            if (!savePrefs()) return;
            ChannelsAccessibilityService s = ChannelsAccessibilityService.getInstance();
            if (s == null) toast("请先开启“视频号辅助识别服务”");
            else {
                s.startAssistantFromUi();
                openWeChat();
                refreshStatus();
            }
        }));
        body.addView(button("暂停识别", v -> {
            ChannelsAccessibilityService s = ChannelsAccessibilityService.getInstance();
            if (s != null) s.pauseAssistant("main-ui");
            refreshStatus();
        }));

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, dp(14), 0, 0);
        body.addView(status);

        TextView note = new TextView(this);
        note.setText("使用方法：\n1. 软件先完成激活。\n2. 填账号1；需要第二个账号时再填账号2。\n3. 保存配置。\n4. 开悬浮窗权限和无障碍服务。\n5. 点“开始识别”，进入你们自己的视频号。\n6. 悬浮窗出现“已锁定：账号名”后才会开始计时和识别。\n7. 如果滑到其他账号，软件立即停止该条的识别，不执行任何动作。\n8. 每40次成功确认后自动暂停。\n\n日志和截图：\n" + FileLogger.basePath(this));
        note.setTextSize(13);
        note.setPadding(0, dp(12), 0, dp(40));
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        return scroll;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void loadPrefs() {
        if (targetAccount1 == null) return;
        targetAccount1.setText(AutomationConfig.targetAccount1(this));
        targetAccount2.setText(AutomationConfig.targetAccount2(this));
        watchSeconds.setText(String.valueOf(AutomationConfig.watchSeconds(this)));
        screenshots.setChecked(AutomationConfig.screenshotOnAction(this));
        autoStart.setChecked(AutomationConfig.autoStart(this));
    }

    private boolean savePrefs() {
        if (!ActivationManager.isActivated(this)) {
            toast("请先完成激活");
            return false;
        }
        String a1 = targetAccount1.getText().toString().trim();
        String a2 = targetAccount2.getText().toString().trim();
        if (a1.isEmpty() && a2.isEmpty()) {
            toast("至少填写一个要锁定的视频号昵称");
            return false;
        }
        int seconds = 15;
        try { seconds = Integer.parseInt(watchSeconds.getText().toString().trim()); } catch (Exception ignored) {}
        seconds = Math.max(5, Math.min(seconds, 600));
        AutomationConfig.prefs(this).edit()
                .putString("target_account_1", a1)
                .putString("target_account_2", a2)
                .putInt("watch_seconds", seconds)
                .putBoolean("screenshot_on_action", screenshots.isChecked())
                .putBoolean("auto_start", autoStart.isChecked())
                .apply();
        toast("配置已保存");
        refreshStatus();
        return true;
    }

    private void openOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("悬浮窗权限已开启");
            return;
        }
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void openWeChat() {
        if (!ActivationManager.isActivated(this)) {
            toast("请先完成软件激活");
            return;
        }
        Intent i = getPackageManager().getLaunchIntentForPackage(AutomationConfig.WECHAT_PACKAGE);
        if (i == null) {
            toast("没有检测到微信");
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void refreshStatus() {
        if (status == null) return;
        ChannelsAccessibilityService s = ChannelsAccessibilityService.getInstance();
        String a1 = AutomationConfig.targetAccount1(this);
        String a2 = AutomationConfig.targetAccount2(this);
        String targets = a1.isEmpty() ? a2 : (a2.isEmpty() ? a1 : a1 + " / " + a2);
        if (targets.isEmpty()) targets = "未设置";
        status.setText("激活状态：" + ActivationManager.statusText(this) +
                "\n锁定账号：" + targets +
                "\n无障碍服务：" + (s == null ? "未连接" : "已连接") +
                "\n悬浮窗：" + (Settings.canDrawOverlays(this) ? "已授权" : "未授权") +
                "\n识别状态：" + (s == null ? "-" : s.getPublicStatus()) +
                "\n40次检查点：固定开启");
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
