package com.hjxm.internalqa;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "settings";
    private Prefs() {}

    public static void saveAccounts(Context c, String a1, String a2) {
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
                .putString("account1", a1.trim())
                .putString("account2", a2.trim())
                .apply();
    }

    public static String account1(Context c) { return p(c).getString("account1", "账号A"); }
    public static String account2(Context c) { return p(c).getString("account2", "账号B"); }
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }
}
