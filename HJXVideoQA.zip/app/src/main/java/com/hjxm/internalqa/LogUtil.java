package com.hjxm.internalqa;

import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class LogUtil {
    private LogUtil() {}

    public static synchronized void log(Context c, String msg) {
        try {
            File dir = new File(c.getExternalFilesDir(null), "logs");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "run.log");
            FileWriter w = new FileWriter(f, true);
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date());
            w.write(ts + "  " + msg + "\n");
            w.close();
        } catch (Exception ignored) {}
    }
}
