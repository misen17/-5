package com.hjxm.internalqa;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText activationInput;
    private EditText account1;
    private EditText account2;
    private TextView activationStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (activationStatus != null) refreshActivationStatus();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.root(this);
        scroll.addView(root);

        root.addView(Ui.title(this, "内部短视频自动测试工具"));
        root.addView(Ui.text(this, "说明：本版本只在本应用自带的测试视频、测试广告、测试直播和测试购物车中运行，用于验证公司内部自动化流程。"));

        root.addView(Ui.text(this, "本机设备码"));
        TextView device = Ui.text(this, ActivationManager.deviceCode(this));
        device.setTextIsSelectable(true);
        root.addView(device);

        activationStatus = Ui.text(this, "");
        root.addView(activationStatus);

        activationInput = Ui.input(this, "输入激活码");
        activationInput.setInputType(InputType.TYPE_CLASS_TEXT);
        root.addView(activationInput);

        Button activate = Ui.button(this, "激活本机");
        activate.setOnClickListener(v -> {
            if (ActivationManager.saveAndValidate(this, activationInput.getText().toString())) {
                Toast.makeText(this, "激活成功", Toast.LENGTH_SHORT).show();
                refreshActivationStatus();
            } else {
                Toast.makeText(this, "激活码无效、已过期或不是本机激活码", Toast.LENGTH_LONG).show();
            }
        });
        root.addView(activate);

        Ui.gap(root, 20);
        root.addView(Ui.title(this, "锁定账号"));
        root.addView(Ui.text(this, "只允许测试以下 1 个或 2 个账号。第二个账号可以留空。"));

        account1 = Ui.input(this, "锁定账号 1");
        account1.setText(Prefs.account1(this));
        root.addView(account1);

        account2 = Ui.input(this, "锁定账号 2（可留空）");
        account2.setText(Prefs.account2(this));
        root.addView(account2);

        Button save = Ui.button(this, "保存账号");
        save.setOnClickListener(v -> {
            if (account1.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "账号1不能为空", Toast.LENGTH_SHORT).show();
                return;
            }
            Prefs.saveAccounts(this, account1.getText().toString(), account2.getText().toString());
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        Ui.gap(root, 24);
        Button start = Ui.button(this, "开始自动测试");
        start.setOnClickListener(v -> startTest());
        root.addView(start);

        root.addView(Ui.text(this,
                "自动测试内容：2倍速播放 → 下一集 → 广告商品随机加入测试购物车 → 测试直播间商品/点赞 → 一部剧结束后切换下一部 → 可暂停/继续/结束。"));

        setContentView(scroll);
        refreshActivationStatus();
    }

    private void refreshActivationStatus() {
        boolean ok = ActivationManager.isActivated(this);
        activationStatus.setText(ok ? "激活状态：已激活" : "激活状态：未激活");
    }

    private void startTest() {
        if (!ActivationManager.isActivated(this)) {
            Toast.makeText(this, "请先使用本机激活码激活", Toast.LENGTH_LONG).show();
            return;
        }
        String a1 = account1.getText().toString().trim();
        String a2 = account2.getText().toString().trim();
        if (a1.isEmpty()) {
            Toast.makeText(this, "请先填写锁定账号1", Toast.LENGTH_SHORT).show();
            return;
        }
        Prefs.saveAccounts(this, a1, a2);
        startActivity(new Intent(this, TestRunnerActivity.class));
    }
}
