package com.hjxm.internalqa;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public final class ActivationManager {
    private static final String PREF = "activation";
    private static final String KEY_CODE = "activation_code";
    // 与管理员激活码生成器保持一致。仅用于公司内部测试工具。
    private static final String SECRET = "HJXM-INTERNAL-QA-2026-8F4C2D9A";

    private ActivationManager() {}

    public static String deviceCode(Context context) {
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null) androidId = "unknown-device";
        String hex = sha256("DEV|" + androidId).substring(0, 16).toUpperCase(Locale.ROOT);
        return hex.substring(0,4) + "-" + hex.substring(4,8) + "-" + hex.substring(8,12) + "-" + hex.substring(12,16);
    }

    public static boolean saveAndValidate(Context context, String code) {
        if (!isValid(context, code)) return false;
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_CODE, code.trim()).apply();
        return true;
    }

    public static boolean isActivated(Context context) {
        String code = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_CODE, "");
        return isValid(context, code);
    }

    public static long expiryMillis(Context context) {
        String code = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_CODE, "");
        String[] parts = code.split("-");
        if (parts.length < 2) return -1;
        try {
            long days = Long.parseLong(parts[0], 36);
            if (days == 0) return Long.MAX_VALUE;
            return days * 86400000L;
        } catch (Exception e) {
            return -1;
        }
    }

    public static boolean isValid(Context context, String raw) {
        if (raw == null) return false;
        String code = raw.trim().toUpperCase(Locale.ROOT);
        String[] parts = code.split("-");
        if (parts.length != 2) return false;
        try {
            long expiryDay = Long.parseLong(parts[0], 36);
            if (expiryDay != 0) {
                long today = System.currentTimeMillis() / 86400000L;
                if (today > expiryDay) return false;
            }
            String expected = signature(deviceCode(context), expiryDay);
            return expected.equals(parts[1]);
        } catch (Exception e) {
            return false;
        }
    }

    public static String signature(String deviceCode, long expiryDay) {
        return sha256(SECRET + "|" + deviceCode.toUpperCase(Locale.ROOT) + "|" + expiryDay)
                .substring(0, 16).toUpperCase(Locale.ROOT);
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
