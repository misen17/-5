package com.hjxm.internalqa;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class TestRunnerActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private TextView accountView, dramaView, episodeView, speedView, sceneView, cartView, likeView, statusView;
    private Button pauseButton;

    private boolean paused = false;
    private boolean stopped = false;
    private int drama = 1;
    private int episode = 1;
    private int cart = 0;
    private int likes = 0;
    private int actionCount = 0;
    private String currentAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!ActivationManager.isActivated(this)) {
            Toast.makeText(this, "激活失效，请重新激活", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        buildUi();
        chooseLockedAccount();
        startEpisode();
    }

    private void buildUi() {
        LinearLayout root = Ui.root(this);
        root.addView(Ui.title(this, "自动测试运行中"));
        accountView = Ui.text(this, ""); root.addView(accountView);
        dramaView = Ui.text(this, ""); root.addView(dramaView);
        episodeView = Ui.text(this, ""); root.addView(episodeView);
        speedView = Ui.text(this, "播放速度：2.0x"); root.addView(speedView);
        sceneView = Ui.text(this, ""); root.addView(sceneView);
        cartView = Ui.text(this, "测试购物车：0"); root.addView(cartView);
        likeView = Ui.text(this, "测试点赞：0"); root.addView(likeView);
        statusView = Ui.text(this, "准备中"); root.addView(statusView);

        Ui.gap(root, 24);
        pauseButton = Ui.button(this, "暂停");
        pauseButton.setOnClickListener(v -> togglePause());
        root.addView(pauseButton);

        Button shot = Ui.button(this, "手动截图");
        shot.setOnClickListener(v -> screenshot("manual"));
        root.addView(shot);

        Button stop = Ui.button(this, "结束");
        stop.setOnClickListener(v -> stopRun());
        root.addView(stop);
        setContentView(root);
    }

    private void chooseLockedAccount() {
        String a1 = Prefs.account1(this);
        String a2 = Prefs.account2(this);
        if (!a2.isEmpty() && random.nextBoolean()) currentAccount = a2;
        else currentAccount = a1;
        accountView.setText("锁定账号：" + currentAccount);
        LogUtil.log(this, "锁定账号=" + currentAccount);
    }

    private void startEpisode() {
        if (stopped) return;
        if (paused) { handler.postDelayed(this::startEpisode, 500); return; }
        if (!ActivationManager.isActivated(this)) { stopRun(); return; }

        sceneView.setText("当前场景：短剧播放");
        dramaView.setText("当前短剧：第 " + drama + " 部");
        episodeView.setText("当前集数：第 " + episode + " 集");
        speedView.setText("播放速度：2.0x");
        statusView.setText("2倍速播放中……");
        LogUtil.log(this, currentAccount + " / 第" + drama + "部 / 第" + episode + "集 / 2倍速播放");

        // 测试环境把一集压缩成约 2 秒，代表 2 倍速自动播放。
        handler.postDelayed(this::afterEpisode, 2000);
    }

    private void afterEpisode() {
        if (stopped) return;
        if (paused) { handler.postDelayed(this::afterEpisode, 500); return; }

        int roll = random.nextInt(100);
        if (roll < 30) handleAd();
        else if (roll < 50) handleLive();
        else nextEpisode();
    }

    private void handleAd() {
        sceneView.setText("当前场景：带商品链接的测试广告");
        statusView.setText("自动打开测试商品链接……");
        LogUtil.log(this, "出现测试广告，自动打开测试商品链接");
        handler.postDelayed(() -> {
            if (paused || stopped) { handleAd(); return; }
            String[] products = {"测试商品A", "测试商品B", "测试商品C"};
            String p = products[random.nextInt(products.length)];
            cart++;
            actionCount++;
            cartView.setText("测试购物车：" + cart);
            statusView.setText("已随机加入 " + p + "，自动退出商品页");
            LogUtil.log(this, "广告商品加购=" + p);
            screenshot("ad-cart");
            handler.postDelayed(this::nextEpisode, 900);
        }, 900);
    }

    private void handleLive() {
        sceneView.setText("当前场景：测试直播间");
        statusView.setText("自动进入测试直播间……");
        LogUtil.log(this, "自动进入测试直播间");
        handler.postDelayed(() -> {
            if (paused || stopped) { handleLive(); return; }
            boolean hasProduct = random.nextBoolean();
            if (hasProduct) {
                String[] products = {"直播测试商品1", "直播测试商品2", "直播测试商品3"};
                String p = products[random.nextInt(products.length)];
                cart++;
                actionCount++;
                cartView.setText("测试购物车：" + cart);
                statusView.setText("直播有商品：已随机加入 " + p + "，准备退出直播");
                LogUtil.log(this, "直播商品加购=" + p);
            } else {
                likes++;
                actionCount++;
                likeView.setText("测试点赞：" + likes);
                statusView.setText("直播无商品：已执行测试点赞，准备退出直播");
                LogUtil.log(this, "直播无商品，执行测试点赞");
            }
            screenshot("live-action");
            handler.postDelayed(this::nextEpisode, 900);
        }, 900);
    }

    private void nextEpisode() {
        if (stopped) return;
        if (paused) { handler.postDelayed(this::nextEpisode, 500); return; }
        episode++;
        if (episode > 8) {
            episode = 1;
            drama++;
            statusView.setText("本部短剧已完成，返回锁定账号主页，切换下一部短剧……");
            LogUtil.log(this, "第" + (drama - 1) + "部测试完成，返回账号主页并切换下一部");
            handler.postDelayed(() -> {
                if (drama > 5) {
                    drama = 1;
                    chooseLockedAccount();
                }
                startEpisode();
            }, 1200);
        } else {
            statusView.setText("自动播放下一集……");
            handler.postDelayed(this::startEpisode, 500);
        }
    }

    private void togglePause() {
        paused = !paused;
        pauseButton.setText(paused ? "继续" : "暂停");
        statusView.setText(paused ? "已暂停" : "继续运行");
        LogUtil.log(this, paused ? "人工暂停" : "人工继续");
        if (!paused) handler.postDelayed(this::startEpisode, 250);
    }

    private void stopRun() {
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        LogUtil.log(this, "人工结束。动作次数=" + actionCount + "，购物车=" + cart + "，点赞=" + likes);
        Toast.makeText(this, "自动测试已结束", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void screenshot(String tag) {
        try {
            View root = getWindow().getDecorView().getRootView();
            Bitmap bmp = Bitmap.createBitmap(root.getWidth(), root.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            root.draw(canvas);
            File dir = new File(getExternalFilesDir(null), "screenshots");
            if (!dir.exists()) dir.mkdirs();
            String ts = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.ROOT).format(new Date());
            File f = new File(dir, ts + "-" + tag + ".png");
            FileOutputStream out = new FileOutputStream(f);
            bmp.compress(Bitmap.CompressFormat.PNG, 95, out);
            out.close();
            bmp.recycle();
        } catch (Exception e) {
            LogUtil.log(this, "截图失败=" + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
