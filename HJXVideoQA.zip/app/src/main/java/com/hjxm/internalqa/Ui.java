package com.hjxm.internalqa;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static TextView title(Context c, String s) {
        TextView v = new TextView(c);
        v.setText(s); v.setTextSize(22); v.setTextColor(Color.BLACK); v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0,16,0,16); return v;
    }
    public static TextView text(Context c, String s) {
        TextView v = new TextView(c); v.setText(s); v.setTextSize(16); v.setTextColor(Color.DKGRAY); v.setPadding(0,8,0,8); return v;
    }
    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c); e.setHint(hint); e.setSingleLine(true); e.setTextSize(16); return e;
    }
    public static Button button(Context c, String s) {
        Button b = new Button(c); b.setText(s); b.setAllCaps(false); return b;
    }
    public static LinearLayout root(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,32,32,32); l.setBackgroundColor(Color.WHITE); return l;
    }
    public static void gap(LinearLayout l, int px) { View v = new View(l.getContext()); l.addView(v, new LinearLayout.LayoutParams(1, px)); }
}
