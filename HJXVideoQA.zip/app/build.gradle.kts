plugins {
    id("com.android.application")
}

android {
    namespace = "com.hjxm.internalqa"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.hjxm.internalqa"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
