import base64, hashlib, hmac, os, sys, time
from datetime import date, timedelta

if len(sys.argv) < 3:
    print('usage: python generate_activation.py DEVICE_ID DAYS')
    sys.exit(1)

device = sys.argv[1].strip().upper()
days = int(sys.argv[2])
secret = os.environ.get('ACTIVATION_SECRET', 'DEMO_INTERNAL_CHANGE_ME').encode()
expiry = (date.today() + timedelta(days=days)).toordinal() - date(1970,1,1).toordinal()
payload = f'{device}|{expiry}'
sig = hmac.new(secret, payload.encode(), hashlib.sha256).hexdigest()[:32]
enc = base64.urlsafe_b64encode(payload.encode()).decode().rstrip('=')
print(f'{enc}.{sig}')
