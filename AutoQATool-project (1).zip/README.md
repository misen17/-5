# 公司内部视频自动化测试工具

这是一个可由 GitHub Actions 直接编译为 APK 的 Android 内部测试工程。

## 重要说明
此版本只操作 APK 自己内置的测试页面，不连接、不控制微信视频号/抖音/快手等第三方平台，也不会产生真实播放、点赞、直播互动或真实购物车数据。

## 已实现
- 一机一码激活
- 两个锁定账号位置
- 2倍速测试播放
- 测试广告商品自动进入并随机加入“测试购物车”
- 测试直播：有商品则随机测试加购，无商品则测试点赞
- 自动下一集、整部结束后下一部短剧
- 暂停 / 继续 / 结束
- 日志
- 手动截图 + 异常截图

## GitHub 最简单打包方法
仓库根目录放：
- `AutoQATool-project.zip`
- `.github/workflows/build-apk.yml`
- `.github/workflows/generate-activation.yml`

建议使用 **Private 私有仓库**。

### 第一次设置激活密钥
GitHub 仓库：Settings → Secrets and variables → Actions → New repository secret

Name：`ACTIVATION_SECRET`

Value：你自己设置一串足够长的随机字符，例如 32 位以上。

然后重新运行 Build Android APK。

### 打 APK
Actions → Build Android APK → Run workflow

成功后在 Artifacts 下载 `InternalVideoQA-APK`。

### 生成激活码
1. 安装 APK，首页复制“设备码”。
2. GitHub → Actions → Generate Activation Code → Run workflow。
3. 输入设备码和有效天数。
4. 运行完成后打开任务，在 **Summary** 里复制激活码。
5. 粘贴到手机 APK 里点击“激活设备”。

如果未配置 `ACTIVATION_SECRET`，工程会使用演示密钥 `DEMO_INTERNAL_CHANGE_ME`；正式内部使用时务必配置仓库 Secret 并重新打包。
