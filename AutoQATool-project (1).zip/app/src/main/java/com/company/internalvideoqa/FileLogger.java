package com.company.internalvideoqa;

import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class FileLogger {
    private FileLogger() {}

    public static void log(Context context, String message) {
        try {
            File dir = new File(context.getFilesDir(), "logs");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "run.log");
            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
            try (FileWriter fw = new FileWriter(file, true)) {
                fw.write(time + "  " + message + "\n");
            }
        } catch (Exception ignored) {}
    }
}
