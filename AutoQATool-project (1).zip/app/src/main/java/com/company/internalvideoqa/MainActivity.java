package com.company.internalvideoqa;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final List<String> cart = new ArrayList<>();

    private EditText activationInput;
    private EditText account1Input;
    private EditText account2Input;
    private TextView activationStatus;
    private TextView status;
    private TextView stats;
    private TextView logView;
    private Button pauseButton;

    private boolean running = false;
    private boolean paused = false;
    private int drama = 1;
    private int episode = 1;
    private int cycle = 0;
    private int likes = 0;
    private int cartAdds = 0;
    private String currentAccount = "";

    private enum State { PLAYING, AD, LIVE_PRODUCT, LIVE_NO_PRODUCT, NEXT }
    private State state = State.PLAYING;
    private int ticks = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        loadPrefs();
        refreshActivation();
        updateStatus("等待开始");
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 48);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("公司内部视频自动化测试工具");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("仅操作本 APK 内置测试页面，不连接或控制第三方视频平台。\n支持：一机一码、两个锁定账号、2倍速测试、广告/直播/商品/测试购物车、自动下一集、暂停和结束。");
        note.setPadding(0, 20, 0, 20);
        root.addView(note);

        TextView device = new TextView(this);
        device.setText("设备码：" + ActivationManager.deviceId(this));
        root.addView(device);

        activationInput = new EditText(this);
        activationInput.setHint("粘贴激活码");
        root.addView(activationInput);

        Button activate = new Button(this);
        activate.setText("激活设备");
        activate.setOnClickListener(v -> {
            if (ActivationManager.activate(this, activationInput.getText().toString())) {
                toast("激活成功");
                refreshActivation();
            } else {
                toast("激活码无效、已过期或不是本机激活码");
            }
        });
        root.addView(activate);

        activationStatus = new TextView(this);
        activationStatus.setPadding(0, 8, 0, 20);
        root.addView(activationStatus);

        account1Input = new EditText(this);
        account1Input.setHint("锁定账号1（必填）");
        root.addView(account1Input);

        account2Input = new EditText(this);
        account2Input.setHint("锁定账号2（可选）");
        root.addView(account2Input);

        Button save = new Button(this);
        save.setText("保存锁定账号");
        save.setOnClickListener(v -> savePrefs());
        root.addView(save);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(controls);

        Button start = new Button(this);
        start.setText("开始");
        start.setOnClickListener(v -> startRun());
        controls.addView(start, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        pauseButton = new Button(this);
        pauseButton.setText("暂停");
        pauseButton.setOnClickListener(v -> togglePause());
        controls.addView(pauseButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button stop = new Button(this);
        stop.setText("结束");
        stop.setOnClickListener(v -> stopRun("人工结束"));
        controls.addView(stop, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button screenshot = new Button(this);
        screenshot.setText("保存当前截图");
        screenshot.setOnClickListener(v -> captureScreen("manual"));
        root.addView(screenshot);

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0, 20, 0, 8);
        root.addView(status);

        stats = new TextView(this);
        root.addView(stats);

        logView = new TextView(this);
        logView.setPadding(0, 16, 0, 0);
        root.addView(logView);
        return sv;
    }

    private void refreshActivation() {
        if (ActivationManager.isActivated(this)) {
            long day = ActivationManager.expiryEpochDay(this);
            activationStatus.setText("激活状态：已激活，到期日(UTC)：" + LocalDate.ofEpochDay(day));
        } else {
            activationStatus.setText("激活状态：未激活");
        }
    }

    private void loadPrefs() {
        android.content.SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        account1Input.setText(sp.getString("a1", ""));
        account2Input.setText(sp.getString("a2", ""));
    }

    private void savePrefs() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
                .putString("a1", account1Input.getText().toString().trim())
                .putString("a2", account2Input.getText().toString().trim())
                .apply();
        toast("账号已保存");
    }

    private void startRun() {
        if (!ActivationManager.isActivated(this)) {
            toast("请先激活设备");
            return;
        }
        String a1 = account1Input.getText().toString().trim();
        if (a1.isEmpty()) {
            toast("请填写锁定账号1");
            return;
        }
        savePrefs();
        running = true;
        paused = false;
        pauseButton.setText("暂停");
        drama = 1;
        episode = 1;
        cycle = 0;
        likes = 0;
        cartAdds = 0;
        cart.clear();
        state = State.PLAYING;
        ticks = 0;
        selectAccount();
        log("开始测试；仅限内置测试环境");
        handler.removeCallbacks(loop);
        handler.post(loop);
    }

    private void togglePause() {
        if (!running) return;
        paused = !paused;
        pauseButton.setText(paused ? "继续" : "暂停");
        log(paused ? "已暂停" : "继续运行");
    }

    private void stopRun(String reason) {
        running = false;
        paused = false;
        handler.removeCallbacks(loop);
        updateStatus("已结束：" + reason);
        log("结束：" + reason);
    }

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try {
                if (!ActivationManager.isActivated(MainActivity.this)) {
                    stopRun("激活码失效或到期");
                    return;
                }
                if (paused) {
                    handler.postDelayed(this, 500);
                    return;
                }
                step();
                handler.postDelayed(this, 500);
            } catch (Exception e) {
                log("异常：" + e.getMessage());
                captureScreen("error");
                stopRun("发生异常，已保存截图");
            }
        }
    };

    private void step() {
        switch (state) {
            case PLAYING:
                ticks++;
                updateStatus(String.format(Locale.CHINA, "锁定账号：%s\n短剧%d · 第%d集\n2倍速测试播放中… %.1f/4.0秒", currentAccount, drama, episode, ticks * 0.5));
                if (ticks >= 8) {
                    ticks = 0;
                    int scene = cycle % 3;
                    if (scene == 0) state = State.AD;
                    else if (scene == 1) state = State.LIVE_PRODUCT;
                    else state = State.LIVE_NO_PRODUCT;
                }
                break;
            case AD:
                updateStatus("广告场景：自动打开测试商品链接 → 随机加入测试购物车 → 返回");
                addRandomProduct("广告");
                state = State.NEXT;
                break;
            case LIVE_PRODUCT:
                updateStatus("直播场景：自动进入测试直播间 → 发现商品 → 随机加入测试购物车 → 退出直播间");
                addRandomProduct("直播");
                state = State.NEXT;
                break;
            case LIVE_NO_PRODUCT:
                updateStatus("直播场景：自动进入测试直播间 → 无商品 → 执行测试点赞 → 退出直播间");
                likes++;
                log("测试点赞 +1");
                state = State.NEXT;
                break;
            case NEXT:
                cycle++;
                if (episode < 3) {
                    episode++;
                    log("自动下一集：第" + episode + "集");
                } else {
                    episode = 1;
                    drama++;
                    selectAccount();
                    log("本剧测试完成，切换到锁定账号主页并进入下一部测试短剧：短剧" + drama);
                }
                state = State.PLAYING;
                ticks = 0;
                break;
        }
        updateStats();
    }

    private void selectAccount() {
        String a1 = account1Input.getText().toString().trim();
        String a2 = account2Input.getText().toString().trim();
        if (a2.isEmpty()) currentAccount = a1;
        else currentAccount = (drama % 2 == 1) ? a1 : a2;
    }

    private void addRandomProduct(String source) {
        String[] products = {"测试商品A", "测试商品B", "测试商品C", "测试商品D"};
        String p = products[random.nextInt(products.length)];
        cart.add(p);
        cartAdds++;
        log(source + "场景加入测试购物车：" + p);
    }

    private void updateStatus(String text) {
        status.setText("当前状态\n" + text);
    }

    private void updateStats() {
        stats.setText("统计：循环=" + cycle + "，测试加购=" + cartAdds + "，测试点赞=" + likes + "，购物车商品=" + cart.size());
    }

    private void log(String text) {
        FileLogger.log(this, text);
        logView.append("• " + text + "\n");
    }

    private void captureScreen(String tag) {
        try {
            View v = getWindow().getDecorView().getRootView();
            Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            v.draw(canvas);
            File dir = new File(getFilesDir(), "screenshots");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, System.currentTimeMillis() + "-" + tag + ".png");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            }
            toast("截图已保存到应用内部目录");
            log("截图：" + out.getName());
        } catch (Exception e) {
            toast("截图失败：" + e.getMessage());
        }
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
