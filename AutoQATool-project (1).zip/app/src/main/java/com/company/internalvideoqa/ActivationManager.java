package com.company.internalvideoqa;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Locale;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class ActivationManager {
    private static final String PREF = "activation";
    private static final String KEY_CODE = "code";

    private ActivationManager() {}

    public static String deviceId(Context context) {
        String id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.trim().isEmpty()) id = "UNKNOWN";
        return id.toUpperCase(Locale.ROOT);
    }

    public static boolean activate(Context context, String code) {
        if (!verify(context, code)) return false;
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_CODE, code.trim()).apply();
        return true;
    }

    public static boolean isActivated(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return verify(context, sp.getString(KEY_CODE, ""));
    }

    public static long expiryEpochDay(Context context) {
        String code = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_CODE, "");
        try {
            String[] parts = code.split("\\.", 2);
            String payload = new String(Base64.decode(parts[0], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8);
            String[] fields = payload.split("\\|", 2);
            return Long.parseLong(fields[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    public static boolean verify(Context context, String code) {
        try {
            if (code == null || code.trim().isEmpty()) return false;
            String[] parts = code.trim().split("\\.", 2);
            if (parts.length != 2) return false;
            String payload = new String(Base64.decode(parts[0], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8);
            String[] fields = payload.split("\\|", 2);
            if (fields.length != 2) return false;

            String device = fields[0];
            long expiryDay = Long.parseLong(fields[1]);
            long today = LocalDate.now(ZoneOffset.UTC).toEpochDay();
            if (!device.equals(deviceId(context)) || expiryDay < today) return false;

            String expected = hmacHex(BuildConfig.ACTIVATION_SECRET, payload).substring(0, 32);
            return constantTimeEquals(expected, parts[1].toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    private static String hmacHex(String secret, String payload) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] out = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : out) sb.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return sb.toString();
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int r = 0;
        for (int i = 0; i < a.length(); i++) r |= a.charAt(i) ^ b.charAt(i);
        return r == 0;
    }
}
